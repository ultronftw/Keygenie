# Configuration file for KeyGenie bot

BOT_TOKEN = "7451215429:AAHGUMU5Vq8FYlfPymIopxhLPu8AowwVdKE"
ADMIN_ID = 7269446938  # Replace with your Telegram user ID (int)

BTC_ADDRESS = "fuckkuu"
LTC_ADDRESS = "yuhdfsufsufsijfisjfour"
USDT_ADDRESS = "dfbghdhrjtyjkyklulo"

PRODUCTS = {
    "Category 1": {"price": "20$", "key": "Alibaba Method"},
    "Category 2": {"price": "30$", "key": "Amazon Method"},
    "Category 3": {"price": "20$", "key": "Introduction"},
    "Category 4": {"price": "50$", "key": "FFull Method"},
}

# Auto verification toggle: True to enable automatic payment verification, False for manual only
AUTO_VERIFICATION_ENABLED = False

# Payment verification API endpoint and API key (example placeholders)
PAYMENT_VERIFICATION_API_URL = "https://api.example.com/verify_payment"
PAYMENT_VERIFICATION_API_KEY = "your_api_key_here"
